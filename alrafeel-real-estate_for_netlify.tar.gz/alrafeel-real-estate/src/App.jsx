import React from 'react';
import { Building2, Phone, Mail, MapPin, Search, Home, Users, Award, Star, Facebook, Instagram } from 'lucide-react';
import './App.css';

function App() {
  const properties = [
    {
      id: 1,
      title: "فيلا فاخرة في بغداد",
      price: "2,500,000 دينار عراقي",
      location: "بغداد - حي المنصور",
      bedrooms: 5,
      bathrooms: 4,
      area: "450 متر مربع",
      image: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=400&h=300&fit=crop",
      type: "للبيع"
    },
    {
      id: 2,
      title: "شقة عصرية في البصرة",
      price: "1,200,000 دينار عراقي",
      location: "البصرة - شط العرب",
      bedrooms: 3,
      bathrooms: 2,
      area: "180 متر مربع",
      image: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=400&h=300&fit=crop",
      type: "للبيع"
    },
    {
      id: 3,
      title: "مكتب تجاري في أربيل",
      price: "800,000 دينار عراقي",
      location: "أربيل - شارع 60 متراً",
      bedrooms: 0,
      bathrooms: 2,
      area: "120 متر مربع",
      image: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=400&h=300&fit=crop",
      type: "للبيع"
    },
    {
      id: 4,
      title: "وحدة سكنية في مجمع جدار ستي",
      price: "تبدأ من 31,000,000 دينار عراقي",
      location: "بغداد - مجمع جدار ستي OCR",
      bedrooms: "متعددة",
      bathrooms: "متعددة",
      area: "متعددة",
      image: "/assets/property-1000047128.jpg",
      type: "للبيع"
    },
    {
      id: 5,
      title: "واجهة تجارية مميزة",
      price: "للاستفسار",
      location: "بغداد - بالقرب من الجامعة الأمريكية",
      bedrooms: "-",
      bathrooms: "-",
      area: "متعددة",
      image: "/assets/property-1000047129.jpg",
      type: "للبيع"
    },
    {
      id: 6,
      title: "وحدة سكنية فاخرة في الكرخ",
      price: "للاستفسار",
      location: "بغداد - قلب الكرخ",
      bedrooms: "متعددة",
      bathrooms: "متعددة",
      area: "متعددة",
      image: "/assets/property-1000047130.jpg",
      type: "للبيع"
    }
  ];

  const services = [
    {
      icon: <Home className="w-8 h-8" />,
      title: "بيع العقارات",
      description: "نساعدك في بيع عقارك بأفضل الأسعار وفي أسرع وقت ممكن"
    },
    {
      icon: <Search className="w-8 h-8" />,
      title: "شراء العقارات",
      description: "نوفر لك أفضل الخيارات العقارية التي تناسب احتياجاتك وميزانيتك"
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "استشارات عقارية",
      description: "فريق من الخبراء يقدم لك النصائح والاستشارات العقارية المتخصصة"
    },
    {
      icon: <Award className="w-8 h-8" />,
      title: "تقييم العقارات",
      description: "خدمات تقييم دقيقة ومعتمدة لجميع أنواع العقارات"
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-lg sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <Building2 className="w-8 h-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-800">الرفيل العقارية</h1>
            </div>
            <nav className="hidden md:flex space-x-8 rtl:space-x-reverse">
              <a href="#home" className="text-gray-700 hover:text-blue-600 transition-colors">الرئيسية</a>
              <a href="#properties" className="text-gray-700 hover:text-blue-600 transition-colors">العقارات</a>
              <a href="#services" className="text-gray-700 hover:text-blue-600 transition-colors">خدماتنا</a>
              <a href="#about" className="text-gray-700 hover:text-blue-600 transition-colors">من نحن</a>
              <a href="#contact" className="text-gray-700 hover:text-blue-600 transition-colors">اتصل بنا</a>
            </nav>
            <div className="flex items-center space-x-4 rtl:space-x-reverse">
              <Phone className="w-5 h-5 text-blue-600" />
              <span className="text-gray-700">+964 774 900 8800</span>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="relative bg-gradient-to-r from-blue-900 to-blue-700 text-white py-20">
        <div className="absolute inset-0 bg-black opacity-50"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center max-w-4xl mx-auto">
            <h2 className="text-5xl font-bold mb-6">اكتشف عقارك المثالي مع الرفيل العقارية</h2>
            <p className="text-xl mb-8">نحن متخصصون في تقديم أفضل الحلول العقارية للبيع والشراء في العراق</p>
            <div className="bg-white rounded-lg p-6 max-w-2xl mx-auto">
              <div className="flex flex-col md:flex-row gap-4">
                <select className="flex-1 p-3 border border-gray-300 rounded-lg text-gray-700">
                  <option>نوع العقار</option>
                  <option>فيلا</option>
                  <option>شقة</option>
                  <option>مكتب</option>
                  <option>أرض</option>
                </select>
                <select className="flex-1 p-3 border border-gray-300 rounded-lg text-gray-700">
                  <option>المدينة</option>
                  <option>بغداد</option>
                  <option>البصرة</option>
                  <option>أربيل</option>
                  <option>الموصل</option>
                </select>
                <button className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center">
                  <Search className="w-5 h-5 ml-2" />
                  بحث
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-800 mb-4">خدماتنا</h3>
            <p className="text-gray-600 max-w-2xl mx-auto">نقدم مجموعة شاملة من الخدمات العقارية المتخصصة لتلبية جميع احتياجاتكم</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow text-center">
                <div className="text-blue-600 mb-4 flex justify-center">{service.icon}</div>
                <h4 className="text-xl font-semibold text-gray-800 mb-3">{service.title}</h4>
                <p className="text-gray-600">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Properties Section */}
      <section id="properties" className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-800 mb-4">العقارات المميزة</h3>
            <p className="text-gray-600 max-w-2xl mx-auto">اكتشف مجموعة مختارة من أفضل العقارات المتاحة للبيع</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {properties.map((property) => (
              <div key={property.id} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
                <div className="relative">
                  <img src={property.image} alt={property.title} className="w-full h-48 object-cover" />
                  <div className="absolute top-4 right-4 bg-blue-600 text-white px-3 py-1 rounded-full text-sm">
                    {property.type}
                  </div>
                </div>
                <div className="p-6">
                  <h4 className="text-xl font-semibold text-gray-800 mb-2">{property.title}</h4>
                  <p className="text-2xl font-bold text-blue-600 mb-3">{property.price}</p>
                  <div className="flex items-center text-gray-600 mb-3">
                    <MapPin className="w-4 h-4 ml-1" />
                    <span>{property.location}</span>
                  </div>
                  <div className="flex justify-between text-sm text-gray-600 mb-4">
                    <span>{property.bedrooms} غرف نوم</span>
                    <span>{property.bathrooms} حمامات</span>
                    <span>{property.area}</span>
                  </div>
                  <button className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors">
                    عرض التفاصيل
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-3xl font-bold text-gray-800 mb-6">من نحن</h3>
              <p className="text-gray-600 mb-6 leading-relaxed">
                 شركة الرفيل العقارية هي إحدى الشركات الرائدة في مجال العقارات في العراق.
                نتميز بخبرتنا الواسعة وفريقنا المتخصص في تقديم أفضل الحلول العقارية لعملائنا.
              </p>
              <p className="text-gray-600 mb-6 leading-relaxed">
                نحن نؤمن بأن العقار ليس مجرد استثمار، بل هو حلم يتحقق ومستقبل يُبنى. 
                لذلك نسعى جاهدين لتقديم خدمات متميزة تلبي تطلعات عملائنا وتحقق أهدافهم.
              </p>
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">500+</div>
                  <div className="text-gray-600">عقار مباع</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">1000+</div>
                  <div className="text-gray-600">عميل راضي</div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=600&h=400&fit=crop" 
                alt="مكتب الرفيل العقارية" 
                className="rounded-lg shadow-lg w-full"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-800 mb-4">آراء عملائنا</h3>
            <p className="text-gray-600 max-w-2xl mx-auto">نفخر بثقة عملائنا ورضاهم عن خدماتنا</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[1, 2, 3].map((item) => (
              <div key={item} className="bg-white p-6 rounded-lg shadow-lg">
                <div className="flex items-center mb-4">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">
                  "خدمة ممتازة وفريق محترف. ساعدوني في العثور على المنزل المثالي لعائلتي. أنصح بالتعامل معهم."
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-gray-300 rounded-full ml-3"></div>
                  <div>
                    <div className="font-semibold text-gray-800">أحمد محمد</div>
                    <div className="text-sm text-gray-600">عميل راضي</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 bg-blue-900 text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold mb-4">اتصل بنا</h3>
            <p className="max-w-2xl mx-auto">نحن هنا لمساعدتك في جميع احتياجاتك العقارية</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <Phone className="w-8 h-8 mx-auto mb-4" />
              <h4 className="text-xl font-semibold mb-2">الهاتف</h4>
              <p>+964 774 900 8800</p>
            </div>
            <div className="text-center">
              <Mail className="w-8 h-8 mx-auto mb-4" />
              <h4 className="text-xl font-semibold mb-2">البريد الإلكتروني</h4>
              <p>info@alrafeel-realestate.com</p>
            </div>
            <div className="text-center">
              <MapPin className="w-8 h-8 mx-auto mb-4" />
              <h4 className="text-xl font-semibold mb-2">العنوان</h4>
              <p>العراق، بغداد</p>
            </div>
          </div>
          <div className="mt-12 max-w-2xl mx-auto">
            <form className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <input 
                type="text" 
                placeholder="الاسم" 
                className="p-3 rounded-lg text-gray-800"
              />
              <input 
                type="email" 
                placeholder="البريد الإلكتروني" 
                className="p-3 rounded-lg text-gray-800"
              />
              <input 
                type="tel" 
                placeholder="رقم الهاتف" 
                className="p-3 rounded-lg text-gray-800 md:col-span-2"
              />
              <textarea 
                placeholder="الرسالة" 
                rows="4" 
                className="p-3 rounded-lg text-gray-800 md:col-span-2"
              ></textarea>
              <button 
                type="submit" 
                className="bg-white text-blue-900 py-3 px-8 rounded-lg hover:bg-gray-100 transition-colors md:col-span-2"
              >
                إرسال الرسالة
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 rtl:space-x-reverse mb-4">
              <Building2 className="w-6 h-6" />
              <span className="text-xl font-bold">الرفيل العقارية</span>
            </div>
            <p className="text-gray-400 mb-4">شريكك الموثوق في عالم العقارات</p>
            <div className="flex items-center justify-center space-x-4 rtl:space-x-reverse mb-4">
              <a href="https://www.facebook.com/share/1UQMr6SsDR/" target="_blank" rel="noopener noreferrer" className="text-white hover:text-blue-400 transition-colors">
                <Facebook className="w-6 h-6" />
              </a>
              <a href="https://www.instagram.com/alrafeel.realestate?igsh=MTI2MXVwbGphanlwaw==" target="_blank" rel="noopener noreferrer" className="text-white hover:text-blue-400 transition-colors">
                <Instagram className="w-6 h-6" />
              </a>
            </div>
            <p className="text-gray-500 text-sm">
              © 2025 الرفيل العقارية. جميع الحقوق محفوظة. تطوير بواسطة <span className="font-bold text-blue-400">Voxin</span>.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;







